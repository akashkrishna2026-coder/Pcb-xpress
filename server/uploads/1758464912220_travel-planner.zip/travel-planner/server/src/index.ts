import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { run, RunResult, RunState } from '@openai/agents';
import { setDefaultOpenAIKey } from '@openai/agents-openai';
import { buildOrchestrator } from './agents/orchestrator';
import { randomUUID } from 'node:crypto';

const PORT = Number(process.env.PORT || 5050);
const CORS_ORIGIN = process.env.CORS_ORIGIN || 'http://localhost:5173';
if (process.env.OPENAI_API_KEY) setDefaultOpenAIKey(process.env.OPENAI_API_KEY as string);

const app = express();
app.use(cors({ origin: CORS_ORIGIN }));
app.use(express.json());

type ClientReg = { res: express.Response; result?: RunResult<any, any> };
const clients = new Map<string, ClientReg>();

function sseHeaders(res: express.Response) {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  (res as any).flushHeaders?.();
}

function sseSend(res: express.Response, event: string, data: any) {
  res.write(`event: ${event}\n`);
  res.write(`data: ${JSON.stringify(data)}\n\n`);
}

const publish = (clientId: string | undefined, event: string, data: any) => {
  if (!clientId) return;
  const client = clients.get(clientId);
  if (client) sseSend(client.res, event, data);
};

app.get('/api/stream', async (req, res) => {
  sseHeaders(res);
  const clientId = randomUUID();
  clients.set(clientId, { res });
  sseSend(res, 'hello', { clientId });

  const input = String(req.query.input || '');
  const agent = buildOrchestrator(publish);

  const runUntilPause = async (state?: RunState<any, any>) => {
    const result = state
      ? await run(agent, state, { stream: true, context: { clientId, publish } })
      : await run(agent, input, { stream: true, context: { clientId, publish } });

    for await (const event of result) {
      if (event.type === 'raw_model_stream_event') {
        const d: any = event.data;
        if (d?.type === 'output_text_delta' && d?.delta) sseSend(res, 'text-delta', d.delta);
      }
      if (event.type === 'run_item_stream_event') {
        sseSend(res, 'run-item', { name: event.name, item: event.item });
      }
    }

    clients.set(clientId, { res, result });
    if (result.interruptions?.length) {
      sseSend(res, 'approval-request', result.interruptions.map(i => ({
        tool: (i as any).rawItem?.name,
        args: (i as any).rawItem?.arguments
      })));
    } else {
      sseSend(res, 'final', result.finalOutput);
    }
  };

  try {
    await runUntilPause();
  } catch (e: any) {
    sseSend(res, 'error', { message: e?.message || 'error' });
    res.end();
    clients.delete(clientId);
  }
});

app.post('/api/approve', async (req, res) => {
  const { clientId, approveAll } = req.body as { clientId: string; approveAll?: boolean };
  const reg = clients.get(clientId);
  if (!reg?.result) return res.status(400).json({ error: 'No pending run for client' });

  const state = reg.result.state;
  for (const interruption of reg.result.interruptions || []) {
    if (approveAll ?? true) state.approve(interruption);
    else state.reject(interruption);
  }

  publish(clientId, 'info', { message: 'Resuming after approval...' });
  const agent = buildOrchestrator(publish);
  const stream = await run(agent, state, { stream: true, context: { clientId, publish } });
  clients.set(clientId, { res: reg.res, result: undefined });

  (async () => {
    for await (const event of stream) {
      if (event.type === 'raw_model_stream_event') {
        const d: any = event.data;
        if (d?.type === 'output_text_delta' && d?.delta) sseSend(reg.res, 'text-delta', d.delta);
      }
      if (event.type === 'run_item_stream_event') {
        sseSend(reg.res, 'run-item', { name: event.name, item: event.item });
      }
    }
    const final = await stream.getFinalResult();
    clients.set(clientId, { res: reg.res, result: final });
    sseSend(reg.res, 'final', final.finalOutput);
  })();

  res.json({ ok: true });
});

app.listen(PORT, () => console.log(`Server on :${PORT}`));
