import { tool } from '@openai/agents';
import { z } from 'zod';
import type { HotelSearchArgs } from '../types';

export const searchHotelsTool = tool({
  name: 'search_hotels',
  description: 'Search hotels in a city; returns mock rooms with nightly prices.',
  parameters: z.object({
    city: z.string(), start: z.string(), end: z.string(), pax: z.number().int().positive(),
    stars: z.number().int().min(1).max(5).optional(), maxPerNight: z.number().optional()
  }),
  async execute(args: HotelSearchArgs, context) {
    const rooms = [
      { hotel_id: 'H001', name: 'Marina Vista', stars: 4, room_id: 'R1', area: 'JBR', price_inr: 5200 },
      { hotel_id: 'H002', name: 'Desert Pearl', stars: 3, room_id: 'R2', area: 'Deira', price_inr: 3400 }
    ];
    const clientId = (context as any)?.clientId as string | undefined;
    (context as any)?.publish?.(clientId, 'hotels_results', { inputs: args, rooms });
    return { inputs: args, rooms };
  }
});

export const bookHotelTool = tool({
  name: 'book_hotel',
  description: 'Book a hotel room; returns mock reservation id. Requires human approval.',
  parameters: z.object({ hotel_id: z.string(), room_id: z.string(), guest_name: z.string(), payment_intent_id: z.string() }),
  needsApproval: true,
  async execute({ hotel_id, room_id, guest_name }) {
    return { reservation_id: 'RSV7890', hotel_id, room_id, guest_name };
  }
});
