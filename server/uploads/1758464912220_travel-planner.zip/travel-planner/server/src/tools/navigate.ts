import { tool } from '@openai/agents';
import { z } from 'zod';
import type { NavigateArgs } from '../types';

export const navigateTool = (publish: (clientId: string | undefined, event: string, data: any) => void) =>
  tool({
    name: 'navigate',
    description: 'Navigate the UI to the given page and provide UI state to render.',
    parameters: z.object({
      page: z.enum(['discover', 'flights', 'hotels', 'checkout']),
      state: z.record(z.any()).default({})
    }),
    async execute(args: NavigateArgs, context) {
      const clientId = (context as any)?.clientId as string | undefined;
      publish(clientId, 'navigate', args);
      return `Navigated to ${args.page}`;
    }
  });
