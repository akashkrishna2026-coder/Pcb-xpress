import { tool } from '@openai/agents';
import { z } from 'zod';

export const createPaymentIntentTool = tool({
  name: 'create_payment_intent',
  description: 'Create a payment intent for INR amount (mocked). Returns intent_id.',
  parameters: z.object({ amount_inr: z.number().int().positive() }),
  async execute({ amount_inr }) {
    return { intent_id: 'pay_intent_123', amount_inr, currency: 'INR', status: 'requires_confirmation' };
  }
});
