import { tool } from '@openai/agents';
import { z } from 'zod';
import type { FlightSearchArgs } from '../types';

export const searchFlightsTool = tool({
  name: 'search_flights',
  description: 'Search flights by origin/destination/dates/pax. Returns mock offers with ids.',
  parameters: z.object({
    origin: z.string(),
    destination: z.string(),
    start: z.string(),
    end: z.string().optional(),
    adults: z.number().int().positive(),
    cabin: z.enum(['economy','premium','business']).default('economy')
  }),
  async execute(args: FlightSearchArgs, context) {
    const offers = [
      { offer_id: 'F001', carrier: 'EK', flight: 'EK531', depart: `${args.start}T08:45`, arrive: `${args.start}T11:10`, price_inr: 21500 },
      { offer_id: 'F002', carrier: 'AI', flight: 'AI933', depart: `${args.start}T14:00`, arrive: `${args.start}T16:25`, price_inr: 19800 }
    ];
    const clientId = (context as any)?.clientId as string | undefined;
    (context as any)?.publish?.(clientId, 'flights_results', { inputs: args, offers });
    return { inputs: args, offers };
  }
});

export const bookFlightTool = tool({
  name: 'book_flight',
  description: 'Book a flight by offer_id; returns mocked PNR. Requires human approval.',
  parameters: z.object({ offer_id: z.string(), passenger_name: z.string(), payment_intent_id: z.string() }),
  needsApproval: true,
  async execute({ offer_id, passenger_name }) {
    return { pnr: 'PNR1234', offer_id, passenger_name };
  }
});
