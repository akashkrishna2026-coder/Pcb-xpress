import { Agent, webSearchTool } from '@openai/agents';
import { navigateTool } from '../tools/navigate';
import { searchFlightsTool, bookFlightTool } from '../tools/flights';
import { searchHotelsTool, bookHotelTool } from '../tools/hotels';
import { createPaymentIntentTool } from '../tools/checkout';

export function buildOrchestrator(publish: (clientId: string | undefined, event: string, data: any) => void) {
  return new Agent({
    name: 'Trip Concierge',
    instructions: `You are a travel concierge. Ask only for missing details (dates, budget per person, hotel class).
Use the 'navigate' tool to move the UI (discover, flights, hotels, checkout).
Always request explicit approval before any booking tool call. Respect budgets and preferences.`,
    tools: [
      webSearchTool(),
      navigateTool(publish),
      searchFlightsTool,
      searchHotelsTool,
      createPaymentIntentTool,
      bookFlightTool,
      bookHotelTool
    ]
  });
}
