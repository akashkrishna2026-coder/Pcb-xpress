export type NavigateArgs = {
  page: 'discover' | 'flights' | 'hotels' | 'checkout';
  state?: Record<string, any>;
};

export type FlightSearchArgs = {
  origin: string; destination: string; start: string; end?: string;
  adults: number; cabin?: 'economy'|'premium'|'business';
};

export type HotelSearchArgs = {
  city: string; start: string; end: string; pax: number; stars?: number; maxPerNight?: number;
};
