export default function Hotels(){
  return (
    <div className="card">
      <h3>Hotels</h3>
      <p>Ask in Chat: “4★ near JBR under 6k/night”. The agent will navigate here with results.</p>
    </div>
  );
}
