import { useEffect, useState } from 'react';

export default function Flights(){
  const [offers, setOffers] = useState<any[]>([]);
  useEffect(()=>{
    // In a fuller app you would subscribe to a store that retains last streamed results.
  },[]);
  return (
    <div className="card">
      <h3>Flights</h3>
      {offers.length===0 ? <div>No results yet – ask in Chat.</div> : (
        <div className="grid">
          {offers.map(o=> (
            <div className="card" key={o.offer_id}>
              <div><strong>{o.carrier} {o.flight}</strong></div>
              <div>{o.depart} → {o.arrive}</div>
              <div>₹ {o.price_inr.toLocaleString('en-IN')}</div>
              <button className="button">Approve & Hold</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
