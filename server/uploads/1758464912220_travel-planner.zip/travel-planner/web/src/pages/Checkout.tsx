export default function Checkout(){
  return (
    <div className="card">
      <h3>Checkout</h3>
      <p>Once you tap Approve, payment intents and bookings will be created, and confirmations appear here.</p>
    </div>
  );
}
