import { useEffect, useRef, useState } from 'react';
import { connectStream, approveAll } from '../api';
import { useNavigate } from 'react-router-dom';

export default function Chat() {
  const [input, setInput] = useState('3 days in Dubai next month for 2 adults from Kochi, under ₹70k. Love beaches & theme parks.');
  const [stream, setStream] = useState('');
  const [clientId, setClientId] = useState<string>('');
  const [approval, setApproval] = useState<{tool:string,args:any}[]|null>(null);
  const routerNav = useNavigate();
  const esRef = useRef<EventSource|null>(null);

  useEffect(()=>()=>{ esRef.current?.close(); },[]);

  return (
    <div className="card">
      <h2>Ask once. I’ll drive the UI.</h2>
      <div style={{display:'flex', gap:8, marginTop:8}}>
        <input className="input" value={input} onChange={e=>setInput(e.target.value)} placeholder="Tell me dates, budget, interests..."/>
        <button className="button" onClick={()=>{
          setStream('');
          setApproval(null);
          esRef.current?.close();
          const es = connectStream(input, {
            onHello: (id)=> setClientId(id),
            onText: (d)=> setStream(s=> s + d),
            onNavigate: ({page, state})=> routerNav(`/${page}`, { state }),
            onFlights: ()=>{}, onHotels: ()=>{},
            onApproval: (req)=> setApproval(req),
            onFinal: ()=>{},
            onRunItem: ()=>{},
            onError: (err)=> console.error(err)
          });
          esRef.current = es;
        }}>Plan my trip</button>
      </div>

      <div className="monolog" style={{marginTop:12, minHeight:120}}>{stream}</div>

      {approval && (
        <div className="modal">
          <div className="card">
            <h3>Approve actions?</h3>
            <p>These tools need your approval:</p>
            <ul>
              {approval.map((a,i)=> <li key={i}><span className="badge">{a.tool}</span> <code>{JSON.stringify(a.args)}</code></li>)}
            </ul>
            <div style={{display:'flex', gap:8, justifyContent:'flex-end', marginTop:12}}>
              <button className="button" onClick={async()=>{ await approveAll(clientId); setApproval(null); }}>Approve & Continue</button>
              <button onClick={()=>{ setApproval(null); }}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      <p style={{color:'var(--muted)'}}>Tip: You can refine by typing again, e.g. <span className="kbd">prefer 4★ near JBR</span></p>
    </div>
  );
}
