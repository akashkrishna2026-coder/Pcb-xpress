import { useLocation } from 'react-router-dom';

export default function Discover(){
  const { state } = useLocation();
  const places = state?.places || [
    { name: 'JBR Beach', why: 'Family-friendly beach with cafes' },
    { name: 'IMG Worlds of Adventure', why: 'Indoor theme park' },
  ];
  return (
    <div className="card">
      <h3>Discover</h3>
      <div className="grid">
        {places.map((p:any,i:number)=> (
          <div key={i} className="card">
            <strong>{p.name}</strong>
            <div style={{ color:'var(--muted)' }}>{p.why}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
