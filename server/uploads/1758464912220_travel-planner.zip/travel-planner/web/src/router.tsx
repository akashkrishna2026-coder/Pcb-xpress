import { createBrowserRouter, NavLink, Outlet } from 'react-router-dom';
import Chat from './pages/Chat';
import Discover from './pages/Discover';
import Flights from './pages/Flights';
import Hotels from './pages/Hotels';
import Checkout from './pages/Checkout';

function Shell() {
  return (
    <>
      <header>
        <strong>AI Travel Planner</strong>
        <nav>
          <NavLink to="/chat" className={({isActive})=> isActive?'active':''}>Chat</NavLink>
          <NavLink to="/discover" className={({isActive})=> isActive?'active':''}>Discover</NavLink>
          <NavLink to="/flights" className={({isActive})=> isActive?'active':''}>Flights</NavLink>
          <NavLink to="/hotels" className={({isActive})=> isActive?'active':''}>Hotels</NavLink>
          <NavLink to="/checkout" className={({isActive})=> isActive?'active':''}>Checkout</NavLink>
        </nav>
      </header>
      <div className="container"><Outlet /></div>
    </>
  );
}

export default createBrowserRouter([
  { path: '/', element: <Shell/>, children: [
    { index: true, element: <Chat/> },
    { path: 'chat', element: <Chat/> },
    { path: 'discover', element: <Discover/> },
    { path: 'flights', element: <Flights/> },
    { path: 'hotels', element: <Hotels/> },
    { path: 'checkout', element: <Checkout/> },
  ]}
]);
