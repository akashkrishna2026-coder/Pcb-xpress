export type SSEHandlers = {
  onHello?: (clientId: string) => void;
  onText?: (delta: string) => void;
  onNavigate?: (args: any) => void;
  onFlights?: (payload: any) => void;
  onHotels?: (payload: any) => void;
  onApproval?: (requests: { tool: string; args: unknown }[]) => void;
  onFinal?: (out: unknown) => void;
  onRunItem?: (payload: any) => void;
  onError?: (err: any) => void;
};

const BASE = import.meta.env.VITE_API_URL || 'http://localhost:5050';

export function connectStream(input: string, handlers: SSEHandlers) {
  const url = `${BASE}/api/stream?input=${encodeURIComponent(input)}`;
  const es = new EventSource(url);
  es.addEventListener('hello', (e) => handlers.onHello?.(JSON.parse((e as MessageEvent).data).clientId));
  es.addEventListener('text-delta', (e) => handlers.onText?.((e as MessageEvent).data));
  es.addEventListener('navigate', (e) => handlers.onNavigate?.(JSON.parse((e as MessageEvent).data)));
  es.addEventListener('flights_results', (e) => handlers.onFlights?.(JSON.parse((e as MessageEvent).data)));
  es.addEventListener('hotels_results', (e) => handlers.onHotels?.(JSON.parse((e as MessageEvent).data)));
  es.addEventListener('approval-request', (e) => handlers.onApproval?.(JSON.parse((e as MessageEvent).data)));
  es.addEventListener('run-item', (e) => handlers.onRunItem?.(JSON.parse((e as MessageEvent).data)));
  es.addEventListener('final', (e) => handlers.onFinal?.(JSON.parse((e as MessageEvent).data)));
  es.addEventListener('error', (e) => handlers.onError?.(e));
  return es;
}

export async function approveAll(clientId: string) {
  await fetch(`${BASE}/api/approve`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ clientId, approveAll: true })
  });
}
