# Auto‑Navigate Travel Planner (React + Node + OpenAI Agents SDK)

## Quick start
1. **Server**
```bash
cd server && cp .env.example .env
# add your OPENAI_API_KEY
npm i && npm run dev
```
2. **Web**
```bash
cd ../web && cp .env.example .env
npm i && npm run dev
```
Open http://localhost:5173 and click **Plan my trip**.

## Configure
- **VITE_API_URL** points to the server (defaults to `http://localhost:5050`).
- Replace tool executors in `server/src/tools/*.ts` with real providers.
