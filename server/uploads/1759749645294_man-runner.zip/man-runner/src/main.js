import * as THREE from 'https://unpkg.com/three@0.160.0/build/three.module.js';
import { GLTFLoader } from 'https://unpkg.com/three@0.160.0/examples/jsm/loaders/GLTFLoader.js';

// ===== Basic setup =====
const canvas = document.getElementById('game');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.outputColorSpace = THREE.SRGBColorSpace;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0b1020);

const camera = new THREE.PerspectiveCamera(60, innerWidth / innerHeight, 0.1, 2000);
camera.position.set(0, 3.5, 8);

// Lights
const hemi = new THREE.HemisphereLight(0xbfdcff, 0x0f1325, 0.8);
scene.add(hemi);
const dir = new THREE.DirectionalLight(0xffffff, 1.0);
dir.position.set(6, 10, 6);
dir.castShadow = true;
dir.shadow.mapSize.set(2048, 2048);
dir.shadow.camera.near = 0.5;
dir.shadow.camera.far = 50;
scene.add(dir);

// Ground
const groundGeo = new THREE.PlaneGeometry(100, 500);
const groundMat = new THREE.MeshStandardMaterial({ color: 0x1a223d, roughness: 0.95, metalness: 0.0 });
const ground = new THREE.Mesh(groundGeo, groundMat);
ground.rotation.x = -Math.PI / 2;
ground.position.z = -200;
ground.receiveShadow = true;
scene.add(ground);

// Lane markers
const laneWidth = 2.2;
const laneCount = 3;
const laneXs = [];
for (let i = 0; i < laneCount; i++) laneXs.push((i - Math.floor(laneCount / 2)) * laneWidth);

// ===== Player =====
const player = new THREE.Group();
player.position.set(0, 0, 0);
scene.add(player);

let playerModel = null;
let playerBox = new THREE.Box3();
let playerVelY = 0;
let onGround = true;
const GRAVITY = -22;
const JUMP_VEL = 9;
let targetX = 0; // smooth lane switching
let currentLane = 1; // middle
let speedZ = 10; // world scroll speed towards player (obstacles move -z)
let alive = true;
let score = 0;

const statusEl = document.getElementById('status');
const scoreEl = document.getElementById('score');

// Load GLB
const loader = new GLTFLoader();
loader.load('./assets/man.glb', (gltf) => {
  playerModel = gltf.scene || gltf.scenes[0];
  playerModel.traverse((o)=>{ if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  // Normalize to ~1.8 units tall
  const box = new THREE.Box3().setFromObject(playerModel);
  const size = new THREE.Vector3();
  box.getSize(size);
  const desiredHeight = 1.8;
  const scale = desiredHeight / (size.y || 1.8);
  playerModel.scale.setScalar(scale);
  // Recompute box and center on origin Y
  const box2 = new THREE.Box3().setFromObject(playerModel);
  const center = new THREE.Vector3();
  box2.getCenter(center);
  playerModel.position.sub(center.multiplyScalar(1)); // move model so its center at (0,0,0)
  // Slightly lift to stand on ground
  playerModel.position.y -= box2.min.y * scale;

  player.add(playerModel);
}, (xhr) => {
  statusEl.textContent = 'Loading model: ' + Math.round((xhr.loaded / xhr.total) * 100) + '%';
}, (err) => {
  statusEl.textContent = 'Failed to load model';
  console.error(err);
});

// Camera follow (simple chase)
function updateCamera(dt) {
  const idealPos = new THREE.Vector3(player.position.x, 3.5, player.position.z + 8);
  camera.position.lerp(idealPos, 1 - Math.pow(0.001, dt)); // smooth
  const lookAt = new THREE.Vector3(player.position.x, player.position.y + 1.2, player.position.z - 6);
  camera.lookAt(lookAt);
}

// ===== Obstacles =====
const obstacles = [];
const pooled = [];
function spawnObstacle() {
  const lane = Math.floor(Math.random() * laneCount);
  const x = laneXs[lane];
  const z = -120; // far ahead
  const h = 1 + Math.random() * 1.5;
  const w = 1.2;
  const d = 1.2;

  let mesh;
  if (pooled.length) {
    mesh = pooled.pop();
    mesh.visible = true;
    mesh.scale.set(w, h, d);
  } else {
    const geo = new THREE.BoxGeometry(w, h, d);
    const mat = new THREE.MeshStandardMaterial({ color: 0xff6666, roughness: 0.8 });
    mesh = new THREE.Mesh(geo, mat);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
  }
  mesh.position.set(x, h/2, z);
  scene.add(mesh);
  obstacles.push(mesh);
}

let spawnTimer = 0;
let spawnInterval = 1.2;

// ===== Input =====
const keys = new Set();
window.addEventListener('keydown', (e)=>{
  keys.add(e.key.toLowerCase());
  // Lane switching
  if (e.key === 'ArrowLeft' || e.key.toLowerCase() === 'a') {
    currentLane = Math.max(0, currentLane - 1);
    targetX = laneXs[currentLane];
  } else if (e.key === 'ArrowRight' || e.key.toLowerCase() === 'd') {
    currentLane = Math.min(laneCount-1, currentLane + 1);
    targetX = laneXs[currentLane];
  } else if (e.key === ' '){ // jump
    if (onGround && alive) {
      onGround = false;
      playerVelY = JUMP_VEL;
    }
  } else if (e.key.toLowerCase() === 'r') {
    restart();
  }
});
window.addEventListener('keyup', (e)=>keys.delete(e.key.toLowerCase()));

// ===== Game loop =====
let last = performance.now();
function tick(now) {
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;

  if (alive) {
    // Move obstacles towards player
    for (let i = obstacles.length - 1; i >= 0; i--) {
      const o = obstacles[i];
      o.position.z += speedZ * dt;
      if (o.position.z > 10) {
        scene.remove(o);
        obstacles.splice(i, 1);
        pooled.push(o);
        score += 10;
      }
    }

    // Spawn new obstacles
    spawnTimer -= dt;
    if (spawnTimer <= 0) {
      spawnObstacle();
      spawnTimer = spawnInterval;
      // Increase difficulty gradually
      spawnInterval = Math.max(0.6, spawnInterval - 0.002);
      speedZ = Math.min(22, speedZ + 0.01);
    }

    // Smooth lane change
    player.position.x += (targetX - player.position.x) * Math.min(1, dt * 10);

    // Jump physics
    playerVelY += GRAVITY * dt;
    player.position.y += playerVelY * dt;
    if (player.position.y <= 0) {
      player.position.y = 0;
      playerVelY = 0;
      onGround = true;
    }

    // Collisions
    if (playerModel) {
      playerBox.setFromObject(playerModel);
      for (const o of obstacles) {
        const box = new THREE.Box3().setFromObject(o);
        if (box.intersectsBox(playerBox)) {
          gameOver();
          break;
        }
      }
    }

    // Score increases with time
    score += dt * 5;
    scoreEl.textContent = 'Score: ' + Math.floor(score);
  }

  // Move ground slowly to fake motion
  ground.position.z += speedZ * dt;
  if (ground.position.z > 0) ground.position.z = -200;

  updateCamera(dt);
  renderer.render(scene, camera);
  requestAnimationFrame(tick);
}
requestAnimationFrame(tick);

function gameOver() {
  alive = false;
  statusEl.textContent = 'Game Over — press R to restart';
  showCenterMessage('Game Over', 'Press R to restart');
}

function restart() {
  // Clear obstacles
  for (const o of obstacles) scene.remove(o);
  obstacles.length = 0;
  // Reset player
  player.position.set(0, 0, 0);
  playerVelY = 0;
  onGround = true;
  currentLane = 1;
  targetX = laneXs[currentLane];
  // Reset score/difficulty
  score = 0;
  spawnInterval = 1.2;
  speedZ = 10;
  alive = true;
  statusEl.textContent = '';
  hideCenterMessage();
}

function showCenterMessage(title, subtitle){
  let el = document.getElementById('center-message');
  if (!el) {
    el = document.createElement('div');
    el.id = 'center-message';
    el.innerHTML = '<div class="card"><h1></h1><p></p></div>';
    document.body.appendChild(el);
  }
  el.querySelector('h1').textContent = title;
  el.querySelector('p').textContent = subtitle || '';
  el.style.display = 'flex';
}
function hideCenterMessage(){
  const el = document.getElementById('center-message');
  if (el) el.style.display = 'none';
}

// Intro message
showCenterMessage('Man Runner', '←/→ or A/D to switch lanes • Space to jump • R to restart');
setTimeout(()=>hideCenterMessage(), 2500);

// Resize
window.addEventListener('resize', ()=>{
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});
