# Man Runner — Three.js Mini Game

A tiny endless runner built with Three.js that uses your uploaded `man.glb` character as the player.

## Controls
- **Left/Right** or **A/D**: switch lanes
- **Space**: jump
- **R**: restart

## How to run locally
Any static HTTP server works. Example commands:

### Option 1: Using `npx serve` (Node.js)
```bash
npx serve man-runner
```
Then open the printed URL in your browser (e.g., http://localhost:3000).

### Option 2: Python 3
```bash
cd man-runner
python -m http.server 8000
```
Open http://localhost:8000 in your browser.

> Opening `index.html` directly from disk (`file://`) will NOT load the GLB due to browser security; run a local server as shown above.

## Files
- `index.html` — minimal page + HUD
- `style.css` — UI styles
- `src/main.js` — game logic (spawns obstacles, handles movement/collisions)
- `assets/man.glb` — your uploaded character model

## Customize
- Tweak difficulty by editing `spawnInterval` and `speedZ` in `src/main.js`.
- Change lane width or count via `laneWidth` and `laneCount`.
- Replace obstacle material/geometry for variety.
