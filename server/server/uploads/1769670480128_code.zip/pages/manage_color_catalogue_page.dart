import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iconsax/iconsax.dart';

// Helper to convert hex strings to Color objects for display
Color hexToColor(String code) {
  try {
    return Color(int.parse(code.substring(1, 7), radix: 16) + 0xFF000000);
  } catch (e) {
    return Colors.grey; // Return a default color if hex is invalid
  }
}

class ManageColorCataloguePage extends StatefulWidget {
  const ManageColorCataloguePage({super.key});

  @override
  State<ManageColorCataloguePage> createState() => _ManageColorCataloguePageState();
}

class _ManageColorCataloguePageState extends State<ManageColorCataloguePage> {
  final DatabaseReference _dbRef = FirebaseDatabase.instance.ref('colorCatalogue');
  List<bool> _isPanelExpanded = [];
  Map<String, List<dynamic>> _shades = {};
  List<dynamic> _families = [];

  @override
  void initState() {
    super.initState();
    _dbRef.onValue.listen((event) {
      if (mounted && event.snapshot.exists) {
        final data = Map<String, dynamic>.from(event.snapshot.value as Map);
        final familiesData = Map<String, dynamic>.from(data['families'] as Map);
        final shadesData = Map<String, dynamic>.from(data['shades'] as Map);

        setState(() {
          _families = familiesData.entries.map((e) => {'key': e.key, ...e.value}).toList();
          _shades = shadesData.map((key, value) => MapEntry(key, (value as Map).entries.map((e) => {'key': e.key, ...e.value}).toList()));
          if (_isPanelExpanded.length != _families.length) {
            _isPanelExpanded = List<bool>.filled(_families.length, false);
          }
        });
      }
    });
  }

  void _showAddEditDialog({String? familyKey, String? shadeKey, Map<String, dynamic>? initialData}) {
    final bool isEditing = initialData != null;
    final bool isFamily = shadeKey == null;
    final _nameController = TextEditingController(text: initialData?['name'] ?? '');
    final _hexController = TextEditingController(text: initialData?['hexCode'] ?? (isFamily ? '#FFFFFF' : '#'));
    final _iconController = TextEditingController(text: initialData?['icon'] ?? 'Iconsax.color_swatch');

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(isEditing ? 'Edit ${isFamily ? 'Family' : 'Shade'}' : 'Add ${isFamily ? 'Family' : 'Shade'}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: _nameController, decoration: InputDecoration(labelText: isFamily ? 'Family Name' : 'Shade Name')),
              if (!isFamily) TextField(controller: _hexController, decoration: const InputDecoration(labelText: 'Hex Code')),
              if (isFamily) TextField(controller: _hexController, decoration: const InputDecoration(labelText: 'Display Color Hex')),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () {
                final data = {'name': _nameController.text, 'hexCode': _hexController.text, if (isFamily) 'icon': _iconController.text};
                if (isFamily) {
                  isEditing ? _dbRef.child('families/$familyKey').update(data) : _dbRef.child('families').push().set(data);
                } else {
                  isEditing ? _dbRef.child('shades/$familyKey/$shadeKey').update(data) : _dbRef.child('shades/$familyKey').push().set(data);
                }
                Navigator.pop(context);
              },
              child: Text(isEditing ? 'Update' : 'Add'),
            ),
          ],
        );
      },
    );
  }

  void _delete(String path, String name) {
    showDialog(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Confirm Deletion'),
      content: Text('Are you sure you want to delete "$name"?'),
      actions: [
        TextButton(child: const Text('Cancel'), onPressed: () => Navigator.of(ctx).pop()),
        TextButton(style: TextButton.styleFrom(foregroundColor: Colors.red), child: const Text('Delete'), onPressed: () {
          _dbRef.child(path).remove();
          Navigator.of(ctx).pop();
        }),
      ],
    ));
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Text("Manage Catalogue", style: GoogleFonts.poppins(color: Colors.white)),
        backgroundColor: Colors.red.shade700,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: _families.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          ExpansionPanelList(
            expansionCallback: (int index, bool isExpanded) {
              setState(() {
                _isPanelExpanded[index] = !isExpanded;
              });
            },
            children: _families.asMap().map((index, family) {
              final familyKey = family['key'];
              final familyShades = _shades[familyKey] ?? [];
              return MapEntry(
                index,
                ExpansionPanel(
                  headerBuilder: (BuildContext context, bool isExpanded) {
                    return ListTile(
                      title: Text(family['name'], style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(icon: const Icon(Iconsax.edit, color: Colors.blue), onPressed: () => _showAddEditDialog(familyKey: familyKey, initialData: family)),
                          IconButton(icon: const Icon(Iconsax.trash, color: Colors.red), onPressed: () => _delete('families/$familyKey', family['name'])),
                        ],
                      ),
                    );
                  },
                  body: Column(
                    children: [
                      ...familyShades.map((shade) => ListTile(
                        leading: CircleAvatar(backgroundColor: hexToColor(shade['hexCode']), radius: 15),
                        title: Text(shade['name']),
                        subtitle: Text(shade['hexCode']),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(icon: const Icon(Iconsax.edit, size: 20, color: Colors.blue), onPressed: () => _showAddEditDialog(familyKey: familyKey, shadeKey: shade['key'], initialData: shade)),
                            IconButton(icon: const Icon(Iconsax.trash, size: 20, color: Colors.red), onPressed: () => _delete('shades/$familyKey/${shade['key']}', shade['name'])),
                          ],
                        ),
                      )).toList(),
                      TextButton.icon(
                        icon: const Icon(Iconsax.add),
                        label: const Text('Add Shade'),
                        onPressed: () => _showAddEditDialog(familyKey: familyKey),
                      )
                    ],
                  ),
                  isExpanded: _isPanelExpanded[index],
                ),
              );
            }).values.toList(),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddEditDialog(),
        label: const Text('Add Family'),
        icon: const Icon(Iconsax.add),
        backgroundColor: Colors.red.shade700,
        foregroundColor: Colors.white,
      ),
    );
  }
}
