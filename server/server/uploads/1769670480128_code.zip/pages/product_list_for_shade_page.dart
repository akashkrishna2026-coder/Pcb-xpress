import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iconsax/iconsax.dart';
import '../product/product_detail_page.dart';

class ProductListForShadePage extends StatelessWidget {
  final String shadeName;
  const ProductListForShadePage({super.key, required this.shadeName});

  // Sample data. In a real app, you would query your database for products
  // matching the `shadeName`.
  final List<Map<String, dynamic>> _products = const [
    {
      'name': 'Royale Luxury Emulsion',
      'description': 'Teflon surface protection',
      'imageUrl': 'assets/color2.jpeg',
      'price': '3499'
    },
    {
      'name': 'Ace Exterior Emulsion',
      'description': 'Weather guard, affordable',
      'imageUrl': 'assets/premium.png',
      'price': '1800'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Text(shadeName, style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.grey.shade800)),
        backgroundColor: Colors.white,
        elevation: 1,
        iconTheme: IconThemeData(color: Colors.grey.shade800),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: _products.length,
        itemBuilder: (context, index) {
          final product = _products[index];
          return _buildProductListItem(context, product);
        },
      ),
    );
  }

  Widget _buildProductListItem(BuildContext context, Map<String, dynamic> product) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 1,
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => ProductDetailPage(product: product)),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.asset(product['imageUrl'], width: 80, height: 80, fit: BoxFit.cover),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(product['name'], style: GoogleFonts.poppins(fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 4),
                    Text(product['description'], style: GoogleFonts.poppins(color: Colors.grey.shade600, fontSize: 12)),
                  ],
                ),
              ),
              const Icon(Iconsax.arrow_right_3, color: Colors.grey),
            ],
          ),
        ),
      ),
    );
  }
}
