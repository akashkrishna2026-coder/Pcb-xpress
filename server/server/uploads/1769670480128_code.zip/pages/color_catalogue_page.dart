import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iconsax/iconsax.dart';
import 'color_shade_page.dart';

// Helper to convert hex strings to Color objects
Color hexToColor(String code) {
  // Handles both #RRGGBB and #AARRGGBB formats
  final buffer = StringBuffer();
  if (code.length == 6 || code.length == 7) buffer.write('ff');
  buffer.write(code.replaceFirst('#', ''));
  return Color(int.parse(buffer.toString(), radix: 16));
}

class ColorCataloguePage extends StatefulWidget {
  const ColorCataloguePage({super.key});

  @override
  State<ColorCataloguePage> createState() => _ColorCataloguePageState();
}

class _ColorCataloguePageState extends State<ColorCataloguePage> {
  // This data would come from your Firebase database in a real app
  final List<Map<String, dynamic>> _colorFamilies = const [
    {'name': 'Reds & Oranges', 'color': Color(0xFFE53935)},
    {'name': 'Yellows & Golds', 'color': Color(0xFFFDD835)},
    {'name': 'Greens & Teals', 'color': Color(0xFF43A047)},
    {'name': 'Blues & Purples', 'color': Color(0xFF1E88E5)},
    {'name': 'Neutrals & Greys', 'color': Color(0xFFBDBDBD)},
    {'name': 'Browns & Earth', 'color': Color(0xFF6D4C41)},
  ];

  final Map<String, List<Map<String, String>>> _allShades = const {
    'Reds & Oranges': [
      {'name': 'Terracotta', 'hexCode': '#E57373'},
      {'name': 'Crimson Red', 'hexCode': '#D32F2F'},
      {'name': 'Sunset Orange', 'hexCode': '#FFA726'},
      {'name': 'Coral Pink', 'hexCode': '#FF8A65'},
      {'name': 'Spiced Paprika', 'hexCode': '#D84315'},
      {'name': 'Blush', 'hexCode': '#FFCDD2'},
    ],
    'Yellows & Golds': [
      {'name': 'Sunbeam', 'hexCode': '#FFF176'},
      {'name': 'Mustard Gold', 'hexCode': '#FFD600'},
      {'name': 'Lemon Tart', 'hexCode': '#FFF59D'},
      {'name': 'Pale Daffodil', 'hexCode': '#FFF9C4'},
    ],
    'Greens & Teals': [
      {'name': 'Forest Green', 'hexCode': '#2E7D32'},
      {'name': 'Mint Ice', 'hexCode': '#A5D6A7'},
      {'name': 'Teal Ocean', 'hexCode': '#00897B'},
      {'name': 'Sage', 'hexCode': '#81C784'},
    ],
    'Blues & Purples': [
      {'name': 'Deep Sea Blue', 'hexCode': '#1565C0'},
      {'name': 'Sky Blue', 'hexCode': '#64B5F6'},
      {'name': 'Lavender', 'hexCode': '#B39DDB'},
      {'name': 'Royal Purple', 'hexCode': '#6A1B9A'},
    ],
    'Neutrals & Greys': [
      {'name': 'Light Grey', 'hexCode': '#E0E0E0'},
      {'name': 'Charcoal', 'hexCode': '#424242'},
      {'name': 'Cool Metal', 'hexCode': '#90A4AE'},
      {'name': 'Warm Taupe', 'hexCode': '#BCAAA4'},
    ],
    'Browns & Earth': [
      {'name': 'Rich Mahogany', 'hexCode': '#4E342E'},
      {'name': 'Beige', 'hexCode': '#D7CCC8'},
      {'name': 'Chocolate', 'hexCode': '#5D4037'},
      {'name': 'Sandy Brown', 'hexCode': '#A1887F'},
    ],
  };

  late String _selectedFamily;
  late List<Map<String, String>> _filteredShades;

  @override
  void initState() {
    super.initState();
    // Initialize with the first color family
    _selectedFamily = _colorFamilies.first['name'];
    _filterShades();
  }

  void _filterShades() {
    setState(() {
      _filteredShades = _allShades[_selectedFamily] ?? [];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Text("Color Catalogue", style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.grey.shade800)),
        backgroundColor: Colors.white,
        elevation: 1,
        shadowColor: Colors.grey.shade200,
        iconTheme: IconThemeData(color: Colors.grey.shade800),
      ),
      body: Column(
        children: [
          _buildCategorySelector(),
          Expanded(
            child: _buildShadesGrid(),
          ),
        ],
      ),
    );
  }

  Widget _buildCategorySelector() {
    return Container(
      height: 60,
      color: Colors.white,
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _colorFamilies.length,
        itemBuilder: (context, index) {
          final family = _colorFamilies[index];
          final bool isSelected = family['name'] == _selectedFamily;
          return GestureDetector(
            onTap: () {
              _selectedFamily = family['name'];
              _filterShades();
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.only(right: 12),
              padding: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                color: isSelected ? Colors.deepOrange : Colors.grey.shade200,
                borderRadius: BorderRadius.circular(30),
              ),
              child: Center(
                child: Text(
                  family['name'],
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.w600,
                    color: isSelected ? Colors.white : Colors.grey.shade700,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildShadesGrid() {
    return GridView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: _filteredShades.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        childAspectRatio: 0.8,
      ),
      itemBuilder: (context, index) {
        final shade = _filteredShades[index];
        return _buildColorSwatch(context, shade);
      },
    );
  }

  Widget _buildColorSwatch(BuildContext context, Map<String, String> shade) {
    final color = hexToColor(shade['hexCode']!);
    return GestureDetector(
      onTap: () {
        // This should navigate to a page listing products for this specific shade.
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => ColorShadePage(familyName: shade['name']!)),
        );
      },
      child: Column(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 5,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Text(shade['name']!, style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
          const SizedBox(height: 2),
          Text(shade['hexCode']!, style: GoogleFonts.poppins(color: Colors.grey.shade600, fontSize: 12)),
        ],
      ),
    );
  }
}

