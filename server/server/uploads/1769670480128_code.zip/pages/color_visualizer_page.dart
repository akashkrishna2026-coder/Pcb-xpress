import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// Helper to convert hex strings to Color objects
Color hexToColor(String code) {
  return Color(int.parse(code.substring(1, 7), radix: 16) + 0xFF000000);
}

class ColorVisualizerPage extends StatefulWidget {
  const ColorVisualizerPage({super.key});

  @override
  State<ColorVisualizerPage> createState() => _ColorVisualizerPageState();
}

class _ColorVisualizerPageState extends State<ColorVisualizerPage> {
  // The currently selected color for the wall
  Color _wallColor = Colors.grey.shade200;

  final List<Map<String, String>> _colorPalette = const [
    {'name': 'Dune Walk', 'hexCode': '#f0e5d1'},
    {'name': 'Vintage Walnut', 'hexCode': '#6f5c4b'},
    {'name': 'Walnut Cream', 'hexCode': '#e2d5c2'},
    {'name': 'Jodhpur Walls', 'hexCode': '#3b78ae'},
    {'name': 'Rainforest Walk', 'hexCode': '#4a7f5a'},
    {'name': 'Terracotta', 'hexCode': '#c06c57'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text("Color Visualizer", style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.grey.shade800)),
        backgroundColor: Colors.white,
        elevation: 1,
        iconTheme: IconThemeData(color: Colors.grey.shade800),
      ),
      body: Column(
        children: [
          // This Expanded widget will contain the room image with the colored wall
          Expanded(
            child: Container(
              margin: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                image: const DecorationImage(
                  image: AssetImage("assets/room_background.png"), // Replace with your transparent room image
                  fit: BoxFit.cover,
                ),
              ),
              // The colored wall is a container behind the room image
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                color: _wallColor,
              ),
            ),
          ),
          // This container at the bottom holds the color palette
          Container(
            padding: const EdgeInsets.all(16.0),
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Choose a Color", style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                SizedBox(
                  height: 60,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: _colorPalette.length,
                    itemBuilder: (context, index) {
                      final colorItem = _colorPalette[index];
                      return _buildColorOption(hexToColor(colorItem['hexCode']!));
                    },
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildColorOption(Color color) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _wallColor = color;
        });
      },
      child: Container(
        width: 60,
        margin: const EdgeInsets.only(right: 12),
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.15),
              blurRadius: 5,
              offset: const Offset(0, 2),
            ),
          ],
        ),
      ),
    );
  }
}
