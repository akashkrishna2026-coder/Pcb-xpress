import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'product_list_for_shade_page.dart';

// Helper to convert hex strings to Color objects
Color hexToColor(String code) {
  return Color(int.parse(code.substring(1, 7), radix: 16) + 0xFF000000);
}

class ColorShadePage extends StatelessWidget {
  final String familyName;
  const ColorShadePage({super.key, required this.familyName});

  // This is sample data. In a real app, you'd fetch shades for the `familyName`.
  final Map<String, List<Map<String, String>>> _shadesData = const {
    'Reds & Oranges': [
      {'name': 'Terracotta', 'hexCode': '#E57373'},
      {'name': 'Crimson', 'hexCode': '#D32F2F'},
      {'name': 'Sunset Orange', 'hexCode': '#FFA726'},
      {'name': 'Coral', 'hexCode': '#FF8A65'},
    ],
    // Add more sample data for other families
  };

  @override
  Widget build(BuildContext context) {
    final shades = _shadesData[familyName] ?? [];

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Text(familyName, style: GoogleFonts.poppins(fontWeight: FontWeight.bold, color: Colors.grey.shade800)),
        backgroundColor: Colors.white,
        elevation: 1,
        iconTheme: IconThemeData(color: Colors.grey.shade800),
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: shades.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 0.8,
        ),
        itemBuilder: (context, index) {
          final shade = shades[index];
          return _buildColorSwatch(context, shade);
        },
      ),
    );
  }

  Widget _buildColorSwatch(BuildContext context, Map<String, String> shade) {
    final color = hexToColor(shade['hexCode']!);
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => ProductListForShadePage(shadeName: shade['name']!)),
        );
      },
      child: Column(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(16),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Text(shade['name']!, style: GoogleFonts.poppins(fontWeight: FontWeight.w600)),
          const SizedBox(height: 2),
          Text(shade['hexCode']!, style: GoogleFonts.poppins(color: Colors.grey.shade600, fontSize: 12)),
        ],
      ),
    );
  }
}
