import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iconsax/iconsax.dart';

import 'manager_requests_page.dart';
import '../admin/all_users_page.dart';
import '../product/manage_products_page.dart';
import '../pages/manage_color_catalogue_page.dart'; // ⭐ IMPORT THE NEW PAGE ⭐

class AdminDashboardPage extends StatelessWidget {
  const AdminDashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Admin Panel", style: GoogleFonts.poppins(color: Colors.white)),
        backgroundColor: Colors.red.shade700,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      backgroundColor: Colors.grey[100],
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          children: [
            _buildDashboardCard(
              context: context,
              icon: Icons.person_add_alt_1,
              title: 'Manager Requests',
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => const ManageUsersPage()));
              },
            ),
            _buildDashboardCard(
              context: context,
              icon: Icons.people_alt,
              title: 'All Users',
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => const AllUsersPage()));
              },
            ),
            _buildDashboardCard(
              context: context,
              icon: Iconsax.box,
              title: 'Manage Products',
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => const ManageProductsPage()));
              },
            ),
            // ⭐ ADDED: New card for managing the color catalogue ⭐
            _buildDashboardCard(
              context: context,
              icon: Iconsax.color_swatch,
              title: 'Manage Catalogue',
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => const ManageColorCataloguePage()));
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDashboardCard({
    required BuildContext context,
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 48, color: Colors.red.shade700),
            const SizedBox(height: 12),
            Text(
              title,
              textAlign: TextAlign.center,
              style: GoogleFonts.poppins(
                fontWeight: FontWeight.w600,
                fontSize: 16,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
