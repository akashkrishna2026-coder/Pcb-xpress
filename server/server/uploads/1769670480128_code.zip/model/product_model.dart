class Product {
  final String name;
  final String description;
  final String imageUrl;
  final String price;
  final String hexCode; 

  Product({
    required this.name,
    required this.description,
    required this.imageUrl,
    required this.price,
    required this.hexCode, // ⭐ NEW: Added to the constructor
  });

  // A factory constructor for creating a new Product instance from a map.
  factory Product.fromMap(Map<String, dynamic> map) {
    return Product(
      name: map['name'] ?? 'No Name',
      description: map['description'] ?? 'No Description',
      imageUrl: map['imageUrl'] ?? '',
      price: map['price'] ?? '0.00',
      hexCode: map['hexCode'] ?? '#FFFFFF', // ⭐ NEW: Parse hex code, default to white
    );
  }
}

